/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registrationandlogin_6;

import java.util.ArrayList;
import java.util.Random;
import javax.swing.JOptionPane;
import java.util.*;
import javax.swing.*;
import java.io.*;
import javax.swing.*;
/**
 *
 * @author HP
 */
public class RegistrationAndLogin_6 {

 

    private static String storedUsername;
    private static String storedPassword;
    private static String storedCell;

    private static final ArrayList<String> sentMessages = new ArrayList<>();
    private static final ArrayList<String> disregardedMessages = new ArrayList<>();
    private static final ArrayList<String> storedMessages = new ArrayList<>();
    private static final ArrayList<String> messageHashes = new ArrayList<>();
    private static final ArrayList<String> messageIDs = new ArrayList<>();

    public static void main(String[] args) {
        registerUser();
        if (loginUser()) {
            JOptionPane.showMessageDialog(null, "Welcome to QuickChat!");
            while (true) {
                String choice = JOptionPane.showInputDialog(
                    "MENU:\n" +
                    "1. Send Message\n" +
                    "2. Show Sent Messages (Sender & Recipient)\n" +
                    "3. Show Longest Sent Message\n" +
                    "4. Search Message by ID\n" +
                    "5. Search Messages by Recipient\n" +
                    "6. Delete Message by Hash\n" +
                    "7. Full Sent Message Report\n" +
                    "8. Quit\n" +
                    "Enter option:"
                );

                switch (choice) {
                    case "1" -> handleMessages();
                    case "2" -> showSenderAndRecipient();
                    case "3" -> showLongestMessage();
                    case "4" -> searchByMessageID();
                    case "5" -> searchByRecipient();
                    case "6" -> deleteByHash();
                    case "7" -> fullReport();
                    case "8" -> {
                        JOptionPane.showMessageDialog(null, "Goodbye!");
                        return;
                    }
                    default -> JOptionPane.showMessageDialog(null, "Invalid option.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Login failed.");
        }
    }

    public static void registerUser() {
        while (true) {
            String username = JOptionPane.showInputDialog("Enter username (max 5 characters, must include '_'):");
            if (username.contains("_") && username.length() <= 5) {
                storedUsername = username;
                JOptionPane.showMessageDialog(null, "Username captured.");
                break;
            }
            JOptionPane.showMessageDialog(null, "Invalid username.");
        }

        while (true) {
            String password = JOptionPane.showInputDialog("Enter password (min 8 chars, 1 uppercase, 1 number, 1 special):");
            if (password.matches("(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%*]).{8,}")) {
                storedPassword = password;
                JOptionPane.showMessageDialog(null, "Password captured.");
                break;
            }
            JOptionPane.showMessageDialog(null, "Invalid password.");
        }

        while (true) {
            String cell = JOptionPane.showInputDialog("Enter cell number (e.g. +27831234567):");
            if (cell.startsWith("+27") && cell.length() == 12) {
                storedCell = cell;
                JOptionPane.showMessageDialog(null, "Cell phone number captured.");
                break;
            }
            JOptionPane.showMessageDialog(null, "Invalid cell phone number.");
        }
    }

    public static boolean loginUser() {
        String username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");
        return username.equals(storedUsername) && password.equals(storedPassword);
    }

    public static void handleMessages() {
        int count = Integer.parseInt(JOptionPane.showInputDialog("How many messages do you want to send?"));

        for (int i = 0; i < count; i++) {
            String recipient;
            while (true) {
                recipient = JOptionPane.showInputDialog("Enter recipient number (start with '+', max 13 chars):");
                if (recipient != null && recipient.startsWith("+") && recipient.length() <= 13) break;
                JOptionPane.showMessageDialog(null, "Invalid recipient.");
            }

            String message;
            while (true) {
                message = JOptionPane.showInputDialog("Enter message (max 250 characters):");
                if (message != null && message.length() <= 250) break;
                JOptionPane.showMessageDialog(null, "Message too long.");
            }

            String messageID = generateUniqueID();
            String messageHash = createMessageHash(messageID, i + 1, message);

            String choice;
            while (true) {
                choice = JOptionPane.showInputDialog("Send / Disregard / Store?");
                if (choice == null) continue;
                choice = choice.toLowerCase();
                if (choice.equals("send") || choice.equals("disregard") || choice.equals("store")) break;
                JOptionPane.showMessageDialog(null, "Invalid option.");
            }

            messageIDs.add(messageID);
            messageHashes.add(messageHash);

            switch (choice) {
                case "send" -> sentMessages.add(storedCell + "|" + recipient + "|" + message);
                case "disregard" -> disregardedMessages.add(message);
                case "store" -> storedMessages.add(message);
            }

            JOptionPane.showMessageDialog(null, "Message ID: " + messageID +
                    "\nHash: " + messageHash +
                    "\nTo: " + recipient +
                    "\nMsg: " + message +
                    "\nStatus: " + choice.toUpperCase());
        }
    }

    private static String generateUniqueID() {
        return String.valueOf(100000000 + new Random().nextInt(900000000));
    }

    private static String createMessageHash(String id, int num, String msg) {
        String[] words = msg.trim().split(" ");
        String first = words.length > 0 ? words[0].toUpperCase() : "EMPTY";
        String last = words.length > 1 ? words[words.length - 1].toUpperCase() : first;
        return id.substring(0, 2) + ":" + num + ":" + first + last;
    }

    private static void showSenderAndRecipient() {
        StringBuilder sb = new StringBuilder("Sender and Recipient List:\n");
        for (String msg : sentMessages) {
            String[] parts = msg.split("\\|");
            sb.append("Sender: ").append(parts[0]).append(" → Recipient: ").append(parts[1]).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void showLongestMessage() {
        String longest = "";
        for (String msg : sentMessages) {
            String[] parts = msg.split("\\|");
            String content = parts[2];
            if (content.length() > longest.length()) longest = content;
        }
        JOptionPane.showMessageDialog(null, "Longest message: " + longest);
    }

    private static void searchByMessageID() {
        String id = JOptionPane.showInputDialog("Enter Message ID to search:");
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) {
                String[] parts = sentMessages.get(i).split("\\|");
                JOptionPane.showMessageDialog(null, "Recipient: " + parts[1] + "\nMessage: " + parts[2]);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }

    private static void searchByRecipient() {
        String recipient = JOptionPane.showInputDialog("Enter recipient number to search:");
        StringBuilder sb = new StringBuilder("Messages sent to " + recipient + ":\n");
        for (String msg : sentMessages) {
            String[] parts = msg.split("\\|");
            if (parts[1].equals(recipient)) sb.append(parts[2]).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void deleteByHash() {
        String hash = JOptionPane.showInputDialog("Enter message hash to delete:");
        int index = messageHashes.indexOf(hash);
        if (index != -1) {
            sentMessages.remove(index);
            messageHashes.remove(index);
            messageIDs.remove(index);
            JOptionPane.showMessageDialog(null, "Message deleted.");
        } else {
            JOptionPane.showMessageDialog(null, "Hash not found.");
        }
    }

    private static void fullReport() {
        StringBuilder sb = new StringBuilder("Full Sent Message Report:\n");
        for (int i = 0; i < sentMessages.size(); i++) {
            String[] parts = sentMessages.get(i).split("\\|");
            sb.append("Hash: ").append(messageHashes.get(i)).append("\n")
              .append("Recipient: ").append(parts[1]).append("\n")
              .append("Message: ").append(parts[2]).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }
}

