
package registrationandlogin_3;

import java.util.Random;
import javax.swing.JOptionPane;


public class Message {
        private int totalMessages = 0;

    public void handleMessages() {
        int count = Integer.parseInt(JOptionPane.showInputDialog(null,
                "How many messages would you like to send?"));

        for (int i = 0; i < count; i++) {
            totalMessages++;

            String recipient;
            while (true) {
                recipient = JOptionPane.showInputDialog(null,
                        "Enter recipient number (start with '+', max 13 chars):");
                if (recipient != null && recipient.startsWith("+") && recipient.length() <= 13) break;
                JOptionPane.showMessageDialog(null, "Invalid recipient number.");
            }

            String message;
            while (true) {
                message = JOptionPane.showInputDialog(null,
                        "Enter your message (max 250 characters):");
                if (message != null && message.length() <= 250) break;
                JOptionPane.showMessageDialog(null,
                        "Message exceeds 250 characters by " + (message.length() - 250));
            }

            String messageID = generateUniqueID();
            String messageHash = createMessageHash(messageID, totalMessages, message);

            String[] options = {"Send", "Disregard", "Store"};
            int choice = JOptionPane.showOptionDialog(null,
                    "Choose what to do with the message:",
                    "Message Action",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    options,
                    options[0]);

            String result = switch (choice) {
                case 0 -> "Message successfully sent.";
                case 1 -> "Message was disregarded.";
                case 2 -> "Message successfully stored.";
                default -> "Unknown action.";
            };

            JOptionPane.showMessageDialog(null,
                    "Message ID: " + messageID +
                            "\nMessage Hash: " + messageHash +
                            "\nRecipient: " + recipient +
                            "\nMessage: " + message +
                            "\nStatus: " + result);
        }

        JOptionPane.showMessageDialog(null, "Returning to main menu...");
    }

    private String generateUniqueID() {
        Random rand = new Random();
        int id = 100000000 + rand.nextInt(900000000);
        return String.valueOf(id);
    }

    private String createMessageHash(String messageID, int msgNum, String message) {
        String[] words = message.trim().split(" ");
        String first = words.length > 0 ? words[0].toUpperCase() : "EMPTY";
        String last = words.length > 1 ? words[words.length - 1].toUpperCase() : first;
        return messageID.substring(0, 2) + ":" + msgNum + ":" + first + last;
    }
}
